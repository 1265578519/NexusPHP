<?php

$lang_takesignup_target = array
(
	'en' => array
	(
	'msg_invited_user_has_registered' => "Invited user has registered",
	'msg_user_you_invited' => "The user you invited ",
	'msg_has_registered' => " has registered just now.",
	),
	'chs' => array
	(
	'msg_invited_user_has_registered' => "你邀请的用户已注册",
	'msg_user_you_invited' => "你邀请的用户 ",
	'msg_has_registered' => " 刚刚已注册。",
	),
	'cht' => array
	(
	'msg_invited_user_has_registered' => "你邀請的用戶已注冊",
	'msg_user_you_invited' => "你邀請的用戶 ",
	'msg_has_registered' => " 剛剛已注冊。",
	),
	'ko' => array
	(
	'msg_invited_user_has_registered' => "당신이 초대한 사용자가 가입을 마쳤습니다.",
	'msg_user_you_invited' => "당신이 초대한 사용자가 ",
	'msg_has_registered' => " 가입을 마쳤습니다.",
	),
	'ja' => array
	(
	'msg_invited_user_has_registered' => "Invited user has registered",
	'msg_user_you_invited' => "The user you invited ",
	'msg_has_registered' => " has registered just now.",
	),
);

?>
