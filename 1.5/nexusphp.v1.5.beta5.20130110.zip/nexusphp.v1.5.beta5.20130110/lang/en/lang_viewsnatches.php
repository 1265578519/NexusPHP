<?php

$lang_viewsnatches = array
(
	'head_snatch_detail' => "Snatch Details",
	'text_snatch_detail_for' => "Snatch Details for ",
	'text_users_top_finished_recently' => "The users at the top finished the download most recently",
	'col_username' => "Username",
	'col_uploaded' => "Uploaded",
	'col_downloaded' => "Downloaded",
	'col_se_time' => "Se. Time",
	'col_le_time' => "Le. Time",
	'col_ratio' => "Ratio",
	'col_when_completed' => "Completed At",
	'col_last_action' => "Last Action",
	'col_seeding' => "Seeding",
	'col_pm_user' => "PM User",
	'col_report_user' => "Report User",
	'col_on_or_off' => "On/Off",
	'text_global' => "Global",
	'text_torrent' => "Torrent",
	'text_yes' => "Yes",
	'text_no'=> "No",
	'title_report' => "Report",
	'col_ip' => "IP",
	'text_per_second' => "/s",
	'text_anonymous' => "anonymous",
	'text_inf' => "Inf.",
	'std_sorry' => "Sorry",
	'std_no_snatched_users' => "No user has snatched this torrent yet.",
);

?>
