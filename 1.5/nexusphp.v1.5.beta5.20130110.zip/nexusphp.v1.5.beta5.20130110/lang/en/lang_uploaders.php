<?php

$lang_uploaders = array
(
	'text_no_uploaders_yet' => "No uploaders found!",
	'head_uploaders' => "Uploaders",
	'text_uploaders' => "Uploaders",
	'col_username' => "Username",
	'col_torrents_size' => "Torrents Size",
	'col_torrents_num' => "Torrents Num",
	'col_last_upload_time' => "Last Upped Time",
	'col_last_upload' => "Last Upped Torrent",
	'text_not_available' => "N/A",
	'submit_go' => "Go",
	'text_select_month' => "Select month: ",
	'text_order_by' => "Order By",
	'text_username' => "Username",
	'text_torrent_size' => "Torrent Size",
	'text_torrent_num' => "Torrent Num",
);

?>
