<?php

$lang_polloverview = array
(
	'std_error' => "Error",
	'head_poll_overview' => "Polls Overview",
	'text_polls_overview' => "Polls Overview",
	'col_id' => "ID",
	'col_added' => "Added",
	'col_question' => "Question",
	'text_no_users_voted' => "Sorry...There are no users that voted!",
	'text_no_poll_id' => "Sorry...There are no polls with that ID!",
	'text_poll_question' => "Poll Questions",
	'col_option_no' => "Option No",
	'col_options' => "Options",
	'text_polls_user_overview' => "Polls User Overview",
	'col_username' => "Username",
	'col_selection' => "Selection",
);

?>
