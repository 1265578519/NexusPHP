<?php

$lang_fastdelete = array
(
	'std_delete_failed' => "Delete failed!",
	'std_missing_form_data' => "missing form data",
	'text_no_permission' => "You're not authorised to delete this torrent, only moderators or above can do that. Please contact one if this is your torrent and you want to delete it.\n",
	'std_delete_torrent' => "Delete torrent",
	'std_delete_torrent_note' => "Sanity check: You are about to delete a torrent. Click",
	'std_here_if_sure' => " here</a> if you are sure."
);

?>
