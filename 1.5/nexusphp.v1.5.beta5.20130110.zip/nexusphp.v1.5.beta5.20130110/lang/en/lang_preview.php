<?php

$lang_preview = array
(
	'text_preview' => "Preview"
);

?>