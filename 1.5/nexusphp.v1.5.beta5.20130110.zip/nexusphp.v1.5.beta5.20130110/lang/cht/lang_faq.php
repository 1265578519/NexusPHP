<?php

$lang_faq = array
(
	'head_faq' => "常見問題",
	'text_welcome_to' => "歡迎來到",
	'text_welcome_content_one' => "我們的目標是提供純粹高品質的東西。因此，只有授權的用戶才能發布種子。如果你有0-day資源的來源，請不要遲疑<a class=\"faqlink\" href=\"contactstaff.php\">聯繫</a>我們！<br /><br />這是非公開BT站點，你必須註冊後才能訪問。",
	'text_welcome_content_two' => "在".$SITENAME."幹任何事前，我們建議你先閱讀站點的<a class=\"faqlink\" href=\"rules.php\">規則</a>！規則只有簡單幾條，但我們要求用戶嚴格遵照。<br /><br />在使用前，請閱讀".$SITENAME."<a class=\"faqlink\" href=\"useragreement.php\">用戶協定</a>。",
	'text_contents' => "目錄",
);

?>
