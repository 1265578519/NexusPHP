<?php

$lang_shoutbox = array
(
	'text_del' => "刪",
	'std_access_denied' => "拒絕訪問",
	'std_access_denied_note' => "游客不允許查看該頁面。",
	'text_to_guest' => "對<b>游客</b>說",
	'text_guest' => "<b>游客</b>",
	'text_ago' => "前",
	'text_helpbox_disabled' => "求助區當前關閉中。你在搞什麼鬼？",
	'text_no_permission_to_shoutbox' => "你沒有在群聊區發言的權力。你在搞什麼鬼？",
);

?>
