<?php

$lang_news = array
(
	'std_delete_news_item' => "刪除最近消息",
	'std_are_you_sure' => "你真的要刪除一條最近消息嗎？如果確定，請點擊",
	'std_here' => "這里",
	'std_if_sure' => "。",
	'std_error' => "錯誤",
	'std_news_body_empty' => "最近消息的正文不能為空！",
	'std_news_title_empty' => "最近消息的標題不能為空！",
	'std_something_weird_happened' => "奇怪的事情發生了。",
	'std_invalid_news_id' => "最近消息的ID不存在：",
	'head_edit_site_news' => "編輯最近消息",
	'text_edit_site_news' => "編輯最近消息",
	'text_notify_users_of_this' => "提醒用戶查看這條消息。",
	'head_site_news' => "最近消息",
	'text_submit_news_item' => "提交新的消息"
);

?>
