<?php

$lang_userhistory = array
(
	'std_error' => "錯誤",
	'std_permission_denied' => "你沒有該權限",
	'std_no_posts_found' => "沒有找到該帖子",
	'head_posts_history' => "帖子歷史",
	'text_posts_history_for' => "用戶帖子歷史-",
	'text_forum' => "<b>論壇:&nbsp;</b>",
	'text_topic' => "<b>主題:&nbsp;</b>",
	'text_post' => "<b>帖子:&nbsp;</b>",
	'text_new' => "新！",
	'text_last_edited' => "最後被",
	'text_at' => "編輯于",
	'std_no_comments_found' => "沒有找到評論",
	'head_comments_history' => "評論歷史",
	'text_comments_history_for' => "用戶評論歷史-",
	'text_torrent' => "<b>種子:&nbsp;</b>",
	'text_comment' => "<b>評論:&nbsp;",
	'std_history_error' => "錯誤",
	'std_unkown_action' => "未知行為",
	'std_invalid_or_no_query' => "無效或沒有該項。"
);

?>
