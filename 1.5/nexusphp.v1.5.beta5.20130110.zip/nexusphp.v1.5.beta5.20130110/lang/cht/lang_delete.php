<?php

$lang_delete = array
(
	'std_delete_failed' => "刪除失敗！",
	'std_missing_form_date' => "有項目未填",
	'std_not_owner' => "你不是發種者！你怎麼會來這？\n",
	'std_invalid_reason' => "無效的理由",
	'std_describe_violated_rule' => "請填寫具體違反的規則。",
	'std_enter_reason' => "請填寫刪除該種子的原因。",
	'head_torrent_deleted' => "成功刪除種子！",
	'text_go_back' => "回到剛才的地方",
	'text_back_to_index' => "返回首頁",
	'text_torrent_deleted' => "成功刪除種子！"
);

?>