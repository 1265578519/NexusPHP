<?php

$lang_deletedisabled = array
(
	'head_delete_diasabled' => "移除被禁用戶",
	'text_delete_diasabled' => "移除被禁用戶",
	'submit_delete_all_disabled_users' => "移除所有被禁用戶",
	'text_delete_disabled_note' => "如果你點擊下面的按鈕，網站中所有的被禁止用戶將被<b>移除</b>。除非<b>十分確定</b>，否則<b>不要</b>點此按鈕。",
	'text_users_are_disabled' => "個用戶被移除。"
);

?>
