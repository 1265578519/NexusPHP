<?php

$lang_uploaders = array
(
	'text_no_uploaders_yet' => "沒有找到發布員！",
	'head_uploaders' => "發布員",
	'text_uploaders' => "發布員",
	'col_username' => "用戶名",
	'col_torrents_size' => "種子大小",
	'col_torrents_num' => "種子數",
	'col_last_upload_time' => "最近發布時間",
	'col_last_upload' => "最近發布種子",
	'text_not_available' => "無",
	'submit_go' => "尋找",
	'text_select_month' => "選取月份：",
	'text_order_by' => "排序",
	'text_username' => "用戶名",
	'text_torrent_size' => "種子大小",
	'text_torrent_num' => "種子數",
);

?>
