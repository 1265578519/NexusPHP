<?php

$lang_polls = array
(
	'std_error' => "錯誤",
	'std_permission_denied' => "你沒有該許可權",
	'std_delete_poll' => "刪除投票",
	'std_delete_poll_confirmation' => "你確定要刪除該投票嗎？點擊\n",
	'std_here_if_sure' => "<b>這裏</b></a>來確認。",
	'std_sorry' => "對不起...",
	'std_no_polls' => "暫時沒有投票！",
	'head_previous_polls' => "以前的投票",
	'text_previous_polls' => "以前的投票",
	'text_ago' => "以前",
	'text_edit' => "編輯",
	'text_delete' => "刪除",
	'text_votes' => "投票數："
);

?>