<?php

$lang_viewnfo = array
(
	'std_puke' => "奧哦",
	'head_view_nfo' => "查看NFO文件",
	'text_nfo_for' => "NFO文件：",
	'title_dos_vy' => "查看DOS樣式",
	'text_dos_vy' => "DOS樣式",
	'title_windows_vy' => "查看Windows樣式",
	'text_windows_vy' => "Windows樣式"
);

?>