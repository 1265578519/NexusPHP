<?php

$lang_viewsnatches = array
(
	'head_snatch_detail' => "完成詳情",
	'text_snatch_detail_for' => "種子完成詳情 - ",
	'text_users_top_finished_recently' => "頂部的用戶最後完成下載",
	'col_username' => "用戶名",
	'col_uploaded' => "上傳",
	'col_downloaded' => "下載",
	'col_ratio' => "分享率",
	'col_when_completed' => "完成",
	'col_last_action' => "最近動向",
	'col_se_time' => "做種時間",
	'col_le_time' => "下載時間",	
	'col_seeding' => "做種",
	'col_pm_user' => "短訊",
	'col_report_user' => "舉報",
	'col_on_or_off' => "線上",
	'text_global' => "全局",
	'text_torrent' => "本種",
	'text_yes' => "是",
	'text_no'=> "否",
	'title_report' => "舉報",
	'col_ip' => "IP",
	'text_per_second' => "/秒",
	'text_anonymous' => "匿名",
	'text_inf' => "無限",
	'std_sorry' => "對不起",
	'text_no_snatched_users' => "還沒有用戶完成該種子。",
);

?>
