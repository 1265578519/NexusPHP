<?php

$lang_makepoll = array
(
	'std_error' => "錯誤",
	'std_no_poll_id' => "不存在此投票ID",
	'std_missing_form_data' => "請填寫比填項目！",
	'head_edit_poll' => "編輯投票",
	'text_edit_poll' => "編輯投票",
	'head_new_poll' => "新的投票",
	'text_day' => "天",
	'text_hour' => "時",
	'text_current_poll' => "注意：當前投票",
	'text_is_only' => "發布僅",
	'text_old' => "。",
	'text_make_poll' => "新的投票",
	'text_question' => "問題",
	'text_option' => "選項",
	'submit_edit_poll' => "編輯投票",
	'submit_create_poll' => "創建投票",
	'text_required' => " 必須填寫"
);

?>
