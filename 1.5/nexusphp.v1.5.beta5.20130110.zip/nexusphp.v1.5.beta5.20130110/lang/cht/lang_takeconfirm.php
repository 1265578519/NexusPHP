<?php

$lang_takeconfirm = array
(
	'std_sorry' => "對不起...",
	'std_no_buddy_to_confirm' => "沒有需要驗證的用戶。:( <br /><br />請點擊",
	'std_here_to_go_back' => "這裏</a>返回。",
	'mail_title' => "網站帳戶驗證",	
	'mail_here' => "這裏",	
	'mail_content_1' => "你好,<br /><br />你的賬號成功通過驗證。你可以進入登錄頁面: ",
	'mail_content_2' => "<br /><br />使用你的賬戶登錄。登錄後請先閱讀站點規則，提問前請自行參考常見問題。<br /><br />祝你好運！ ".$SITENAME."!<br /><br />如果你不認識邀請你的人，請將本郵件轉發至".$REPORTMAIL."<br />------<br />".$SITENAME." 網站"
);
?>
