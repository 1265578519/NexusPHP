<?php

$lang_mailtest = array
(
	'head_mail_test' => "郵件測試",
	'text_mail_test' => "郵件測試",
	'row_enter_email' => "匯入郵箱位址",
	'text_enter_email_note' => "匯入用于接收測試郵件的郵箱位址，如yourname@gmail.com",
	'submit_send_it' => "傳送！",
	'text_smtp_testing_mail' => "測試郵件",
	'std_error' => "錯誤",
	'std_invalid_email_address' => "郵箱位址無效！",
	'mail_test_mail_content' => "你好，如果你看見這個資訊，你的SMTP郵件傳送功能正常。祝愉快！",
	'std_success' => "成功",
	'std_success_note' => "沒有錯誤發生，但這不意為着郵件肯定已成功傳送。請檢查郵箱。"
);

?>
