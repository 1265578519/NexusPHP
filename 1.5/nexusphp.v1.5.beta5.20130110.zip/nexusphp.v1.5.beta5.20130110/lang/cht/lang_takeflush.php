<?php

$lang_takeflush = array
(
	'std_failed' => "失敗",
	'std_success' => "成功",
	'std_ghost_torrents_cleaned' => "個冗余種子被成功清除。",
	'std_cannot_flush_others' => "你只能清除自己的冗余種子"
);

?>