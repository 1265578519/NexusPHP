<?php

$lang_moresmilies = array
(
	'head_more_smilies' => "更多可点表情",
	'text_close' => "关闭",
);

?>
