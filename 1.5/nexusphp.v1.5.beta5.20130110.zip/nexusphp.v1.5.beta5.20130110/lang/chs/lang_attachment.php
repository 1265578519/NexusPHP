<?php

$lang_attachment = array
(
	'text_nothing_received' => "失败！没有收到文件！",
	'text_file_number_limit_reached' => "失败！你暂时不能上传更多附件！请等待些时间。",
	'text_file_size_too_big' => "失败！文件过大。",
	'text_file_extension_not_allowed' => "失败！不允许该文件扩展名。",
	'text_invalid_image_file' => "失败！图片文件无效。",
	'text_cannot_move_file' => "失败！无法移动上传的文件。",
	'submit_upload' => "上传",
	'text_left' => "今日剩余：",
	'text_of' => "/",
	'text_size_limit' => "大小限制：",
	'text_file_extensions' => "允许扩展名：",
	'text_mouse_over_here' => "鼠标移至此",
	'text_small_thumbnail' => "小缩略图",
);

?>
