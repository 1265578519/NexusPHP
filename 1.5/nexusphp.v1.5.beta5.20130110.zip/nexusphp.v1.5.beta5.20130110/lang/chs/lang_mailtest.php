<?php

$lang_mailtest = array
(
	'head_mail_test' => "邮件测试",
	'text_mail_test' => "邮件测试",
	'row_enter_email' => "输入邮箱地址",
	'text_enter_email_note' => "输入用于接收测试邮件的邮箱地址，如yourname@gmail.com",
	'submit_send_it' => "发送！",
	'text_smtp_testing_mail' => "测试邮件",
	'std_error' => "错误",
	'std_invalid_email_address' => "邮箱地址无效！",
	'mail_test_mail_content' => "你好，如果你看见这个信息，你的SMTP邮件发送功能正常。祝愉快！",
	'std_success' => "成功",
	'std_success_note' => "没有错误发生，但这不意为着邮件肯定已成功发送。请检查邮箱。"
);

?>
