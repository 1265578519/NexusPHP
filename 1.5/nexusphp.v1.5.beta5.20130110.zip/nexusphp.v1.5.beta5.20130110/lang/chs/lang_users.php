<?php

$lang_users = array
(
	'head_users' => "用户",
	'text_users' => "<h1>用户</h1>\n",
	'text_search' => "搜索:",
	'select_any_class' => "(任何等级)",
	'submit_okay' => "给我搜",
	'text_prev' => "上一页",
	'text_next' => "下一页",
	'col_user_name' => "用户名",
	'col_registered' => "注册",
	'col_last_access' => "最后访问",
	'col_class' => "等级",
	'col_country' => "国家/地区",
	'select_any_country'=> "(任何国家/地区)",
);

?>
