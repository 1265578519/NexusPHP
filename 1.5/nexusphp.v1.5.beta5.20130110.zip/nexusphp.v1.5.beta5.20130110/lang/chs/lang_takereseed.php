<?php

$lang_takereseed = array
(
	'head_reseed_request' => "续种请求！",
	'std_it_worked' => "成功了！完成下载的用户将收到请求续种的短讯。",
	'std_error' => "错误",
	'std_torrent_not_dead' => "该种子没有断种。",
	'std_reseed_sent_recently' => "该种子在过去15分钟内已收到一次续种请求。请耐心等待好心人续种。",
);

?>
