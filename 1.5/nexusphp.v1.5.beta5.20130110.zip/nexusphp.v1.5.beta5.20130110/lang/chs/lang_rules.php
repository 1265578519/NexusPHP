<?php

$lang_rules = array
(
	'head_rules' => "规则"
);

?>
