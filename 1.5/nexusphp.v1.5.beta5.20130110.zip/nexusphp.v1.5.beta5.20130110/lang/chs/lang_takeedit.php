<?php

$lang_takeedit = array
(
	'std_edit_failed' => "编辑失败！",
	'std_missing_form_data' => "有项目没有填写",
	'std_not_owner' => "你不是发种者！怎么回事？\n",
	'std_nfo_too_big' => "NFO过大！最大为65,535字节。",
	'std_cannot_move_torrent' => "你没有将种子移至另一区的权限。另外，你怎么会到这？"
);

?>