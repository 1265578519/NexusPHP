<?php

$lang_sendmessage = array
(
	'std_error' => "错误",
	'std_permission_denied' => "没有该权限",
	'head_send_message' => "发送短讯",
	'text_mass_message' => "群发短讯给",
	'text_users' => "个用户",
	'text_subject' => "主题：",
	'text_comment' => "评论：",
	'text_from' => "发送者：",
	'text_take_snapshot' => "使用快照：",
	'submit_send_it' => "发送",
	'submit_preview' => "预览",
	'text_templates' => "模版：",
	'submit_use' => "使用",
	'std_no_user_id' => "没有该ID的用户。",
	'text_message_to' => "发送短讯给",
	'checkbox_delete_message_replying_to' => "回复后删除",
	'checkbox_save_message_to_sendbox' => "保存到发件箱"
);

?>