<?php

$lang_makepoll = array
(
	'std_error' => "错误",
	'std_no_poll_id' => "不存在此投票ID",
	'std_missing_form_data' => "请填写必填项目！",
	'head_edit_poll' => "编辑投票",
	'text_edit_poll' => "编辑投票",
	'head_new_poll' => "新的投票",
	'text_day' => "天",
	'text_hour' => "时",
	'text_current_poll' => "注意：当前投票",
	'text_is_only' => "发布仅",
	'text_old' => "。",
	'text_make_poll' => "新的投票",
	'text_question' => "问题",
	'text_option' => "选项",
	'submit_edit_poll' => "编辑投票",
	'submit_create_poll' => "创建投票",
	'text_required' => " 必须填写"
);

?>
