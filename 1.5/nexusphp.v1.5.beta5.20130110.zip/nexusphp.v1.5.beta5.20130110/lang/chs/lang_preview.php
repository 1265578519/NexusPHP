<?php

$lang_preview = array
(
	'text_preview' => "预览"
);

?>