<?php

$lang_takelogin = array
(
	'std_login_fail_note' => "<b>错误</b>: 用户名或密码不正确！<br /><br />忘记密码了？<b><a href=recover.php>找回</a></b>你的密码！",
	'std_login_fail' => "登录失败！",
	'std_account_disabled' => "该账号已被禁用。",
	'std_user_account_unconfirmed' => "该账户还未通过验证。如果你没有收到验证邮件，试试<a href='confirm_resend.php'><b>重新发送验证邮件</b></a>。",
);

?>
