<?php

$lang_shoutbox = array
(
	'text_del' => "删",
	'std_access_denied' => "拒绝访问",
	'std_access_denied_note' => "游客不允许查看该页面。",
	'text_to_guest' => "对<b>游客</b>说",
	'text_guest' => "<b>游客</b>",
	'text_ago' => "前",
	'text_helpbox_disabled' => "求助区当前关闭中。你在搞什么鬼？",
	'text_no_permission_to_shoutbox' => "你没有在群聊区发言的权力。你在搞什么鬼？",
);

?>
