<?php

$lang_viewfilelist = array
(
	'col_path' => "路径",
);

?>
