<?php

$lang_viewsnatches = array
(
	'head_snatch_detail' => "完成详情",
	'text_snatch_detail_for' => "种子完成详情 - ",
	'text_users_top_finished_recently' => "顶部的用户最后完成下载",
	'col_username' => "用户名",
	'col_uploaded' => "上传",
	'col_downloaded' => "下载",
	'col_ratio' => "分享率",
	'col_when_completed' => "完成",
	'col_last_action' => "最近动向",
	'col_se_time' => "做种时间",
	'col_le_time' => "下载时间",
	'col_seeding' => "做种",
	'col_pm_user' => "短讯",
	'col_report_user' => "举报",
	'col_on_or_off' => "在线",
	'text_global' => "全局",
	'text_torrent' => "本种",
	'text_yes' => "是",
	'text_no'=> "否",
	'title_report' => "举报",
	'col_ip' => "IP",
	'text_per_second' => "/秒",
	'text_anonymous' => "匿名",
	'text_inf' => "无限",
	'std_sorry' => "对不起",
	'text_no_snatched_users' => "还没有用户完成该种子。",
);

?>
